EventSource example
===================

To try this example, you need GNU `make` and `git` in your PATH.

To build the example, run the following command:

``` bash
$ make
```

To start the release in the foreground:

``` bash
$ ./_rel/eventsource_example/bin/eventsource_example console
```

Then point your EventSource capable browser at
[http://localhost:8080](http://localhost:8080).
