-module(custom_config).

-compile(export_all).

test() ->
    ok.
