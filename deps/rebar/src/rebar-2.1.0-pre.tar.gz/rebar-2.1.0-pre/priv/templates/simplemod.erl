-module({{modid}}).

-export([my_func/0]).

my_func() ->
    ok.
